package resourcesdemo.cmps312.qu.edu.qa.implicitexplicitpermissionsdemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomeScreenActivity extends AppCompatActivity {
Button existButton, infoButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        existButton = (Button) findViewById(R.id.exit_app_btn);
        infoButton = (Button) findViewById(R.id.learn_solar_system_btn);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.mipmap.solar_system);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
    }

    public void exit(View v){finish();}
    public void openPlanetActivity(View v){
        Intent i = new Intent(this,PlanetsActivity.class);
        startActivity(i);
    }

}
