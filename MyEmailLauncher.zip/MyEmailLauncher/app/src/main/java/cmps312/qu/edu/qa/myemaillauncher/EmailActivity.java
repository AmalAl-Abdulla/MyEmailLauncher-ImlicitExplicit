package cmps312.qu.edu.qa.myemaillauncher;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class EmailActivity extends AppCompatActivity {
    ImageView imageView;
    TextView subjetTextView, bodyTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);

        imageView = (ImageView) findViewById(R.id.imageView);
        subjetTextView = (TextView) findViewById(R.id.subject_content_text_view);
        bodyTextView = (TextView) findViewById(R.id.body_content_text_view);

        String text = getIntent().getStringExtra(Intent.EXTRA_SUBJECT);
        subjetTextView.setText(text);

        String text2 = getIntent().getStringExtra(Intent.EXTRA_TEXT);
        bodyTextView.setText(text2);

        Uri imageUri = (Uri) getIntent().getParcelableExtra(Intent.EXTRA_STREAM);
        //imageView.setImageResource(imageUri.getPort());

    }

}
